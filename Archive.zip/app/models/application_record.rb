# frozen_string_literal: true

# Rails app record
class ApplicationRecord < ActiveRecord::Base
  self.abstract_class = true
end
