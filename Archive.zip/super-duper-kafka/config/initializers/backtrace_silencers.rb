# frozen_string_literal: true

Rails.backtrace_cleaner.remove_silencers! if ENV['BACKTRACE']
