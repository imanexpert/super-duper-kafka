class Attendance < ApplicationRecord
end
