# frozen_string_literal: true

# Main job class for all the Rails jobs
class ApplicationJob < ActiveJob::Base
end
