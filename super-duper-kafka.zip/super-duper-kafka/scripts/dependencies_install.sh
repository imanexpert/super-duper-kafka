#!/bin/bash
cd /var/www/my-app/
bundle install