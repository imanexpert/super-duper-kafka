# frozen_string_literal: true

# Rails app helper
module ApplicationHelper
end
